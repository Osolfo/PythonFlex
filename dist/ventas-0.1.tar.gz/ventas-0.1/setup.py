from setuptools import setup

setup(
    name="ventas",
    version="0.1",
    description="paquete de clientes para ventas",
    author="Adolfo",
    author_email="adolfochef2017@gmail.com",
    packages=["ventas"],
)